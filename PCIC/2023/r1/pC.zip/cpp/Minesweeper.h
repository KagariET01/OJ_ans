#ifndef MINESWEEPER_H_
#define MINESWEEPER_H_

void defuse_mines(int N);

int detect(int x,int y);

void defuse(int x,int y);

#endif // MINESWEEPER_H_
