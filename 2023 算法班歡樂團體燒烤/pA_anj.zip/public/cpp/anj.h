
int fib0();
int fib1();
