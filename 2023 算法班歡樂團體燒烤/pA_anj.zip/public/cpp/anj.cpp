#include "anj.h"

int fib0() {

}

int fib1() {

}
